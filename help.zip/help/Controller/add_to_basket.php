<?php
// BackOffice/DB/add_to_basket.php

session_start();

// Include the database connection file
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize the product ID
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    if ($product_id > 0) {
        // Get the session ID
        $session_id = session_id();

        try {
            // Begin transaction
            $pdo->beginTransaction();

            // Check if a cart exists for this session
            $stmt = $pdo->prepare('SELECT id FROM carts WHERE session_id = ?');
            $stmt->execute([$session_id]);
            $cart = $stmt->fetch();

            if ($cart) {
                $cart_id = $cart['id'];
            } else {
                // Create a new cart
                $stmt = $pdo->prepare('INSERT INTO carts (session_id) VALUES (?)');
                $stmt->execute([$session_id]);
                $cart_id = $pdo->lastInsertId();
            }

            // Check if the product is already in the cart
            $stmt = $pdo->prepare('SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ?');
            $stmt->execute([$cart_id, $product_id]);
            $cart_item = $stmt->fetch();

            if ($cart_item) {
                // Update the quantity
                $new_quantity = $cart_item['quantity'] + 1;
                $stmt = $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
                $stmt->execute([$new_quantity, $cart_item['id']]);
            } else {
                // Add new item to the cart
                $stmt = $pdo->prepare('INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)');
                $stmt->execute([$cart_id, $product_id, 1]);
            }

            // Commit transaction
            $pdo->commit();

            // Redirect back to products page with success message
            header('Location: ../View/FrontOffice/mainpage/products.php?added=1');
            exit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $pdo->rollBack();
            // Handle the error (you can log it and display a user-friendly message)
            echo "<p class='error'>An error occurred while adding the product to the basket. Please try again.</p>";
            exit();
        }
    } else {
        // Invalid product ID
        echo "<p class='error'>Invalid product selected.</p>";
        exit();
    }
} else {
    // Invalid request method
    header('Location: ../View/FrontOffice/mainpageproducts.php');
    exit();
}
?>