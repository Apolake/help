<!-- FrontOffice/blog/delete_product.php -->
<?php
// Check if 'id' is set in GET request
if (!isset($_GET['id'])) {
    header('Location: ../View/FrontOffice/mainpage/products.php');
    exit();
}

$product_id = intval($_GET['id']);

// Include the database connection file
require_once '../config.php';

// Fetch the product to get the image path
$stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    echo "<p class='error'>Product not found.</p>";
    exit();
}

// Delete the product from the database
$delete_stmt = $pdo->prepare('DELETE FROM products WHERE id = ?');
if ($delete_stmt->execute([$product_id])) {
    // Optionally, delete the image file
    if (file_exists($product['image'])) {
        unlink($product['image']);
    }
    header('Location: ../View/FrontOffice/mainpage/products.php?deleted=1');
    exit();
} else {
    echo "<p class='error'>Error: Could not delete the product.</p>";
}
?>