<?php
// FrontOffice/basket.php

session_start();

// Include the database connection file
require_once '../../../config.php';

// Get the session ID
$session_id = session_id();

// Handle quantity update and item removal
try {
    // Fetch the cart for the current session
    $stmt = $pdo->prepare('SELECT id FROM carts WHERE session_id = ?');
    $stmt->execute([$session_id]);
    $cart = $stmt->fetch();

    if ($cart) {
        $cart_id = $cart['id'];

        // Handle quantity update
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
            $action = $_POST['action'];
            $item_id = intval($_POST['item_id']); // This should be cart_item_id

            // Fetch current quantity
            $stmt = $pdo->prepare('SELECT quantity FROM cart_items WHERE id = ? AND cart_id = ?');
            $stmt->execute([$item_id, $cart_id]);
            $current = $stmt->fetch();

            if ($current) {
                if ($action == 'increase') {
                    $new_quantity = $current['quantity'] + 1;
                } elseif ($action == 'decrease') {
                    $new_quantity = $current['quantity'] - 1;
                    if ($new_quantity < 1) {
                        $new_quantity = 0;
                    }
                }

                if ($new_quantity > 0) {
                    // Update the quantity in the database
                    $stmt = $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE id = ? AND cart_id = ?');
                    $stmt->execute([$new_quantity, $item_id, $cart_id]);
                } else {
                    // Remove the item from the cart
                    $stmt = $pdo->prepare('DELETE FROM cart_items WHERE id = ? AND cart_id = ?');
                    $stmt->execute([$item_id, $cart_id]);
                }
            }

            // Redirect to avoid form resubmission
            header('Location: basket.php');
            exit();
        }

        // Handle item removal
        if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['remove'])) {
            $item_id = intval($_GET['remove']);

            // Remove the item from the cart
            $stmt = $pdo->prepare('DELETE FROM cart_items WHERE id = ? AND cart_id = ?');
            $stmt->execute([$item_id, $cart_id]);

            // Redirect to avoid URL manipulation issues
            header('Location: basket.php');
            exit();
        }

        // Fetch all items in the cart
        $stmt = $pdo->prepare('
            SELECT cart_items.id AS cart_item_id, products.id AS product_id, products.name, products.price, products.image, cart_items.quantity
            FROM cart_items
            JOIN products ON cart_items.product_id = products.id
            WHERE cart_items.cart_id = ?
        ');
        $stmt->execute([$cart_id]);
        $cart_items = $stmt->fetchAll();
    } else {
        $cart_items = [];
    }
} catch (Exception $e) {
    echo "<p class='error'>An error occurred while fetching your basket. Please try again.</p>";
    exit();
}

// Calculate totals
$subtotal = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$tax = $subtotal * 0.10; // 10% tax
$total = $subtotal + $tax;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GreenRoot - Basket</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="basket.php" class="basket-button">Basket</a>
                <a href="../login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="products.php">Our Products</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="../event/event.html">Events</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <main>
        <h1>Your Basket</h1>
        <?php if (empty($cart_items)): ?>
            <p>Your basket is empty. <a href="products.php">Shop now!</a></p>
        <?php else: ?>
            <div class="basket-container">
                <table class="basket-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td>
                                    <div class="basket-product">
                                        <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                        <span><?php echo htmlspecialchars($item['name']); ?></span>
                                    </div>
                                </td>
                                <td>$<?php echo number_format($item['price'], 2); ?></td>
                                <td>
                                    <form action="basket.php" method="post" class="quantity-form">
                                        <input type="hidden" name="item_id" value="<?php echo $item['cart_item_id']; ?>">
                                        <button type="submit" name="action" value="decrease" class="quantity-btn decrease">&minus;</button>
                                        <span class="quantity-display"><?php echo $item['quantity']; ?></span>
                                        <button type="submit" name="action" value="increase" class="quantity-btn increase">&plus;</button>
                                    </form>
                                </td>
                                <td class="subtotal">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                <td><a href="basket.php?remove=<?php echo $item['cart_item_id']; ?>" class="remove-btn" onclick="return confirm('Are you sure you want to remove this product from the basket?');">Remove</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Order Summary -->
                <div class="basket-summary">
                    <h2>Order Summary</h2>
                    <p>Subtotal: <span id="subtotal-amount">$<?php echo number_format($subtotal, 2); ?></span></p>
                    <p>Tax (10%): <span id="tax-amount">$<?php echo number_format($tax, 2); ?></span></p>
                    <p><strong>Total: <span id="total-amount">$<?php echo number_format($total, 2); ?></span></strong></p>
                    <button class="checkout-btn" onclick="document.getElementById('checkout-form').scrollIntoView();">Proceed to Checkout</button>
                </div>
            </div>

            <!-- Checkout Form -->
            <section class="checkout">
                <h2>Checkout</h2>
                <form id="checkout-form" action="process_checkout.php" method="post">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="customer_name" required>
                    </div>
                    <div class="form-group">
                        <label for="address">Address:</label>
                        <textarea id="address" name="customer_address" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="payment-method">Payment Method:</label>
                        <select id="payment-method" name="payment_method" required>
                            <option value="card">Credit/Debit Card</option>
                            <option value="paypal">PayPal</option>
                        </select>
                    </div>
                    <!-- Card Details -->
                    <div class="card-details">
                        <div class="form-group">
                            <label for="card-number">Card Number:</label>
                            <input type="text" id="card-number" name="card_number">
                        </div>
                        <div class="form-group">
                            <label for="expiry-date">Expiry Date:</label>
                            <input type="month" id="expiry-date" name="expiry_date">
                        </div>
                        <div class="form-group">
                            <label for="cvv">CVV:</label>
                            <input type="text" id="cvv" name="cvv">
                        </div>
                    </div>
                    <button type="submit" class="place-order-btn">Place Order</button>
                </form>
            </section>
        <?php endif; ?>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="scripts.js"></script>
</body>
</html>