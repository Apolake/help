<?php
// FrontOffice/process_checkout.php

session_start();

// Include the database connection file
require_once '../../../config.php';

// Get the session ID
$session_id = session_id();

// Fetch the cart for the current session
$stmt = $pdo->prepare('SELECT id FROM carts WHERE session_id = ?');
$stmt->execute([$session_id]);
$cart = $stmt->fetch();

if (!$cart) {
    echo "<p class='error'>Your basket is empty.</p>";
    exit();
}

$cart_id = $cart['id'];

// Fetch all items in the cart
$stmt = $pdo->prepare('
    SELECT products.id, products.name, products.price, cart_items.quantity
    FROM cart_items
    JOIN products ON cart_items.product_id = products.id
    WHERE cart_items.cart_id = ?
');
$stmt->execute([$cart_id]);
$cart_items = $stmt->fetchAll();

if (empty($cart_items)) {
    echo "<p class='error'>Your basket is empty.</p>";
    exit();
}

// Retrieve and sanitize form data
$customer_name = isset($_POST['customer_name']) ? htmlspecialchars(trim($_POST['customer_name'])) : '';
$customer_address = isset($_POST['customer_address']) ? htmlspecialchars(trim($_POST['customer_address'])) : '';
$payment_method = isset($_POST['payment_method']) ? htmlspecialchars(trim($_POST['payment_method'])) : '';
$card_number = isset($_POST['card_number']) ? htmlspecialchars(trim($_POST['card_number'])) : null;
$expiry_date = isset($_POST['expiry_date']) ? htmlspecialchars(trim($_POST['expiry_date'])) : null;
$cvv = isset($_POST['cvv']) ? htmlspecialchars(trim($_POST['cvv'])) : null;

// Basic validation
$errors = [];

if (empty($customer_name)) {
    $errors[] = "Name is required.";
}

if (empty($customer_address)) {
    $errors[] = "Address is required.";
}

if (empty($payment_method)) {
    $errors[] = "Payment method is required.";
}

if ($payment_method === 'card') {
    if (empty($card_number) || empty($expiry_date) || empty($cvv)) {
        $errors[] = "All card details are required.";
    }
    // Additional validation for card details can be added here
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "<p class='error'>{$error}</p>";
    }
    echo "<p><a href='basket.php'>Go back to Basket</a></p>";
    exit();
}

try {
    // Begin transaction
    $pdo->beginTransaction();

    // Insert the order into 'orders' table
    $stmt = $pdo->prepare('
        INSERT INTO orders (customer_name, customer_address, payment_method, card_number, expiry_date, cvv, created_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ');
    $stmt->execute([
        $customer_name,
        $customer_address,
        $payment_method,
        $card_number,
        $expiry_date,
        $cvv
    ]);

    $order_id = $pdo->lastInsertId();

    // Insert order items into 'order_items' table
    $stmt = $pdo->prepare('
        INSERT INTO order_items (order_id, product_id, quantity, price)
        VALUES (?, ?, ?, ?)
    ');

    foreach ($cart_items as $item) {
        $stmt->execute([
            $order_id,
            $item['id'],
            $item['quantity'],
            $item['price']
        ]);
    }

    // Clear the basket by deleting cart_items
    $stmt = $pdo->prepare('DELETE FROM cart_items WHERE cart_id = ?');
    $stmt->execute([$cart_id]);

    // Optionally, delete the cart
    $stmt = $pdo->prepare('DELETE FROM carts WHERE id = ?');
    $stmt->execute([$cart_id]);

    // Commit transaction
    $pdo->commit();

    // Redirect to the Order Confirmation page with the order ID
    header("Location: order_confirmation.php?order_id={$order_id}");
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    echo "<p class='error'>An error occurred while processing your order. Please try again.</p>";
    exit();
}
?>