// Carousel functionality
let slideIndex = 0;
showSlides();

function showSlides() {
    let i;
    const slides = document.getElementsByClassName("slide");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1 }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 10000); // Change image every 10 seconds
}

function plusSlides(n) {
    slideIndex += n - 1;
    showSlides();
}

// Subscription form handler
const subscribeForm = document.getElementById('subscribe-form');
subscribeForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const email = subscribeForm.querySelector('input[type="email"]').value;
    alert(`Thank you for subscribing, ${email}!`);
    subscribeForm.reset();
});

// Show More Events button handler
const showMoreEventsButton = document.getElementById('show-more-events');
showMoreEventsButton.addEventListener('click', function() {
    alert('More events coming soon!');
});

// Add to Cart button handler
const addToCartButtons = document.querySelectorAll('.add-to-cart');
addToCartButtons.forEach(function(button) {
    button.addEventListener('click', function() {
        alert('Product added to cart!');
    });
});

// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Quantity Buttons
    const quantityButtons = document.querySelectorAll('.quantity-btn');
    quantityButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const quantityInput = this.parentElement.querySelector('.quantity-input');
            let quantity = parseInt(quantityInput.value);
            if (this.classList.contains('increase')) {
                quantity++;
            } else if (this.classList.contains('decrease') && quantity > 1) {
                quantity--;
            }
            quantityInput.value = quantity;
            updateSubtotal(this.closest('tr'));
            updateTotal();
        });
    });

    // Remove Buttons
    const removeButtons = document.querySelectorAll('.remove-btn');
    removeButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            row.parentElement.removeChild(row);
            updateTotal();
        });
    });

    // Payment Method Toggle
    const paymentMethodSelect = document.getElementById('payment-method');
    const cardDetailsSection = document.querySelector('.card-details');

    paymentMethodSelect.addEventListener('change', function() {
        if (this.value === 'card') {
            cardDetailsSection.style.display = 'block';
        } else {
            cardDetailsSection.style.display = 'none';
        }
    });

    // Checkout Form Submission
    const checkoutForm = document.getElementById('checkout-form');
    checkoutForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        alert(`Thank you for your purchase, ${name}!`);
        checkoutForm.reset();
        updateTotal();
    });

    // Initial Total Calculation
    updateTotal();
});

function updateSubtotal(row) {
    const priceText = row.querySelector('td:nth-child(2)').textContent;
    const price = parseFloat(priceText.replace('$', ''));
    const quantity = parseInt(row.querySelector('.quantity-input').value);
    const subtotalCell = row.querySelector('.subtotal');
    const subtotal = (price * quantity).toFixed(2);
    subtotalCell.textContent = `$${subtotal}`;
}

function updateTotal() {
    let subtotal = 0;
    const subtotalCells = document.querySelectorAll('.subtotal');
    subtotalCells.forEach(function(cell) {
        const amount = parseFloat(cell.textContent.replace('$', ''));
        subtotal += amount;
    });
    const tax = (subtotal * 0.10).toFixed(2); // Assuming 10% tax
    const total = (subtotal + parseFloat(tax)).toFixed(2);

    document.getElementById('subtotal-amount').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('tax-amount').textContent = `$${tax}`;
    document.getElementById('total-amount').textContent = `$${total}`;
}