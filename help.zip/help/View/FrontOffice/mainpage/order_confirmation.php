<?php
// FrontOffice/order_confirmation.php

session_start();

// Include the database connection file
require_once '../../../config.php';

// Retrieve and sanitize the order ID from the URL
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id <= 0) {
    echo "<p class='error'>Invalid order ID.</p>";
    exit();
}

try {
    // Fetch the order details
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        echo "<p class='error'>Order not found.</p>";
        exit();
    }

    // Fetch the order items
    $stmt = $pdo->prepare('
        SELECT products.name, products.price, order_items.quantity
        FROM order_items
        JOIN products ON order_items.product_id = products.id
        WHERE order_items.order_id = ?
    ');
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll();

    if (empty($order_items)) {
        echo "<p class='error'>No items found for this order.</p>";
        exit();
    }

    // Calculate totals
    $subtotal = 0;
    foreach ($order_items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    $tax = $subtotal * 0.10; // 10% tax
    $total = $subtotal + $tax;
} catch (Exception $e) {
    echo "<p class='error'>An error occurred while retrieving your order details. Please try again.</p>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - GreenRoot</title>
    <link rel="stylesheet" href="styles.css"> <!-- Adjust the path if necessary -->
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="basket.php" class="basket-button">Basket</a>
                <a href="../login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="products.php">Our Products</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="../event/event.html">Events</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <main>
        <h1>Thank You for Your Order!</h1>
        <p class="success">Dear <?php echo htmlspecialchars($order['customer_name']); ?>,</p>
        <p>Your order has been successfully placed. Below are your order details:</p>

        <h2>Order Summary</h2>
        <table class="order-summary-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price (per KG)</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($order_items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="order-totals">
            <p>Subtotal: <strong>$<?php echo number_format($subtotal, 2); ?></strong></p>
            <p>Tax (10%): <strong>$<?php echo number_format($tax, 2); ?></strong></p>
            <p><strong>Total: $<?php echo number_format($total, 2); ?></strong></p>
        </div>

        <h2>Shipping Details</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
        <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($order['customer_address'])); ?></p>

        <p>We will notify you once your order is shipped.</p>

        <a href="products.php" class="continue-shopping-btn">Continue Shopping</a>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="scripts.js"></script>
</body>
</html>