<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GreenRoot - Our Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="basket.php" class="basket-button">Basket</a>
                <a href="../login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="products.php">Our Products</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Events</a></li>
        </ul>
    </nav>

    <main>
        <h1>Our Products</h1>
        <a href="../../BackOffice/main/addprod.php" class="add-product-button">Add New Product</a>
        <section class="product-grid">
            <?php
            // Include the database connection file
            require_once '../../../config.php';

            // Fetch all products from the database
            $stmt = $pdo->query('SELECT * FROM products ORDER BY created_at DESC');
            while ($product = $stmt->fetch()):
            ?>
                <!-- Inside your product loop in products.php -->
                <div class="product-card">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="price">$<?php echo number_format($product['price'], 2); ?> per KG</p>
                    <p class="availability"><?php echo htmlspecialchars($product['availability']); ?></p>
                    <form action="../../../Controller/add_to_basket.php" method="post">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <button type="submit" class="add-to-cart">Add to Cart</button>
                    </form>
                    <a href="../../BackOffice/main/editprod.php?id=<?php echo $product['id']; ?>" class="edit-button">Edit</a>
                    <a href="../../../Controller/deleteprod.php?id=<?php echo $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                </div>
            <?php endwhile; ?>
            <?php
                // Check if a product was deleted
                if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
                    echo "<p class='success'>Product deleted successfully!</p>";
                }
            ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <script src="scripts.js"></script>
</body>
</html>