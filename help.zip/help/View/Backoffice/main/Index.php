<?php
// index.php

// Include the database connection file
require_once '../../../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - GreenRoot</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="../../FrontOffice/mainpage/basket.php" class="basket-button">Basket</a>
                <a href="../../FrontOffice/login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../../FrontOffice/mainpage/index.html">Return to Front Office</a></li>
            <li><a href="index.php">BackOffice: Manage Orders</a></li>
        </ul>
    </nav>

    <main>
        <h1>Manage Orders</h1>
        <?php
        // Check if an order was deleted
        if (isset($_GET['deleted'])) {
            echo '<p class="success">Order deleted successfully.</p>';
        }
        ?>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Customer Address</th>
                    <th>Payment Method</th>
                    <th>Order Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch all orders from the database
                $stmt = $pdo->query('SELECT * FROM orders ORDER BY created_at DESC');
                while ($order = $stmt->fetch(PDO::FETCH_ASSOC)):
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($order['id']); ?></td>
                    <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['customer_address']); ?></td>
                    <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                    <td><?php echo htmlspecialchars($order['created_at']); ?></td>
                    <td>
                        <a href="edit_order.php?id=<?php echo $order['id']; ?>" class="edit-button">Edit</a>
                        <a href="delete_order.php?id=<?php echo $order['id']; ?>" onclick="return confirm('Are you sure you want to delete this order?');" class="delete-button">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <script src="scripts.js"></script>
</body>
</html>