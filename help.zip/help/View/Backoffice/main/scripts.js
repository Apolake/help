document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('.add-product-form');
    const name = document.getElementById('name');
    const description = document.getElementById('description');
    const price = document.getElementById('price');
    const image = document.getElementById('image');
    const errorContainer = document.createElement('div');
    errorContainer.className = 'error-messages';
    form.prepend(errorContainer);

    form.addEventListener('submit', function (e) {
        let errors = [];

        // Validate Product Name
        const nameValue = name.value.trim();
        if (nameValue.length < 3) {
            errors.push('Product name must be at least 3 characters long.');
        }

        // Validate Description
        const descriptionValue = description.value.trim();
        if (descriptionValue.length < 20) {
            errors.push('Description must be at least 20 characters long.');
        }

        // Validate Price
        const priceValue = parseFloat(price.value);
        if (isNaN(priceValue) || priceValue <= 0) {
            errors.push('Price must be a positive number.');
        }

        // Validate Image
        if (image.files.length > 0) {
            const file = image.files[0];
            const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!allowedTypes.includes(file.type)) {
                errors.push('Invalid image format. Allowed formats: JPG, PNG, GIF.');
            }
            if (file.size > 5 * 1024 * 1024) { // 5MB
                errors.push('Image size should not exceed 5MB.');
            }
        } else {
            errors.push('Product image is required.');
        }

        // Display Errors
        if (errors.length > 0) {
            e.preventDefault();
            errorContainer.innerHTML = '';
            errors.forEach(function (error) {
                const p = document.createElement('p');
                p.className = 'error';
                p.textContent = error;
                errorContainer.appendChild(p);
            });
            window.scrollTo(0, 0);
        }
    });
});