<?php
// delete_order.php

// Check if 'id' is set in GET request
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$order_id = intval($_GET['id']);

// Include the database connection file
require_once '../../../config.php';

try {
    // Begin transaction
    $pdo->beginTransaction();

    // Delete order items associated with the order
    $stmt = $pdo->prepare('DELETE FROM order_items WHERE order_id = ?');
    $stmt->execute([$order_id]);

    // Delete the order from the database
    $stmt = $pdo->prepare('DELETE FROM orders WHERE id = ?');
    $stmt->execute([$order_id]);

    // Commit transaction
    $pdo->commit();

    // Redirect to index with success message
    header('Location: index.php?deleted=1');
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    echo "<p class='error'>Error: Could not delete the order.</p>";
}
?>