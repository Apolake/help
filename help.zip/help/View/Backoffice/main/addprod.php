<!-- FrontOffice/blog/add_product.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - GreenRoot</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="../../FrontOffice/mainpage/basket.php" class="basket-button">Basket</a>
                <a href="../../FrontOffice/login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../../FrontOffice/mainpage/index.html">Home</a></li>
            <li><a href="../../FrontOffice/mainpage/products.php">Our Products</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Events</a></li>
        </ul>
    </nav>

    <main>
        <h1>Add New Product</h1>
        <form action="addprod.php" method="post" enctype="multipart/form-data" class="add-product-form">
            <label for="name" class="label-text">Product Name:</label>
            <input type="text" id="name" name="name" placeholder="e.g., Organic Bananas" required>

            <label for="description" class="label-text">Description:</label>
            <textarea id="description" name="description" rows="4" placeholder="Describe the product..." required></textarea>

            <label for="price" class="label-text">Price (per KG):</label>
            <input type="number" step="0.01" id="price" name="price" placeholder="e.g., 5.99" required>

            <label for="availability" class="label-text">Availability:</label>
            <select id="availability" name="availability" required>
                <option value="In Stock">In Stock</option>
                <option value="Limited Stock">Limited Stock</option>
                <option value="Out of Stock">Out of Stock</option>
            </select>

            <label for="image" class="label-text">Product Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required class="file-input">

            <button type="submit" class="upload-button">Add Product</button>
        </form>

        <?php
        // Include the database connection file
        require_once '../../../config.php';

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Retrieve and sanitize form data
            $name = htmlspecialchars(trim($_POST['name']));
            $description = htmlspecialchars(trim($_POST['description']));
            $price = floatval($_POST['price']);
            $availability = $_POST['availability'];

            // Handle image upload
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['image']['name'];
                $filetype = $_FILES['image']['type'];
                $filesize = $_FILES['image']['size'];

                // Verify file extension
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                if (!in_array(strtolower($ext), $allowed)) {
                    echo "<p class='error'>Error: Please select a valid file format.</p>";
                    exit;
                }

                // Verify file size - 5MB maximum
                if ($filesize > 5 * 1024 * 1024) {
                    echo "<p class='error'>Error: File size is larger than the allowed limit.</p>";
                    exit;
                }

                // Verify MIME type
                if (in_array($filetype, ['image/jpeg', 'image/png', 'image/gif'])) {
                    // Check whether file exists before uploading it
                    if (file_exists("../../FrontOffice/mainpage/images/" . $filename)) {
                        echo "<p class='error'>Error: " . $filename . " already exists.</p>";
                        exit;
                    } else {
                        move_uploaded_file($_FILES['image']['tmp_name'], "../../FrontOffice/mainpage/images/" . $filename);
                        // Insert into database
                        $stmt = $pdo->prepare('INSERT INTO products (name, description, price, availability, image) VALUES (?, ?, ?, ?, ?)');
                        if ($stmt->execute([$name, $description, $price, $availability, "../../FrontOffice/mainpage/images/" . $filename])) {
                            echo "<p class='success'>Product added successfully!</p>";
                        } else {
                            echo "<p class='error'>Error: Could not add the product.</p>";
                        }
                    }
                } else {
                    echo "<p class='error'>Error: There was a problem uploading your file. Please try again.</p>";
                }
            } else {
                echo "<p class='error'>Error: " . $_FILES['image']['error'] . "</p>";
            }
        }
        ?>
    </main>

    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <script src="scripts.js"></script>
</body>
</html>