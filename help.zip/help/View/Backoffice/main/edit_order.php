<?php
// edit_order.php

// Include the database connection file
require_once '../../../config.php';

// Initialize variables
$order_id = $customer_name = $customer_address = $payment_method = "";
$error = $success = "";

// Check if 'id' is set in GET request
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $order_id = intval($_GET['id']);

    // Fetch the order details from the database
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        // Populate variables with existing data
        $customer_name = $order['customer_name'];
        $customer_address = $order['customer_address'];
        $payment_method = $order['payment_method'];
    } else {
        echo "<p class='error'>Order not found.</p>";
        exit();
    }
} else {
    echo "<p class='error'>Invalid order ID.</p>";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize form data
    $customer_name = trim($_POST['customer_name']);
    $customer_address = trim($_POST['customer_address']);
    $payment_method = trim($_POST['payment_method']);

    // Basic validation
    if (empty($customer_name) || empty($customer_address) || empty($payment_method)) {
        $error = "All fields are required.";
    }

    // If no errors, update the order in the database
    if (empty($error)) {
        $stmt = $pdo->prepare('UPDATE orders SET customer_name = ?, customer_address = ?, payment_method = ? WHERE id = ?');
        if ($stmt->execute([$customer_name, $customer_address, $payment_method, $order_id])) {
            $success = "Order updated successfully!";
        } else {
            $error = "Failed to update the order.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Order - GreenRoot</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="../../FrontOffice/mainpage/basket.php" class="basket-button">Basket</a>
                <a href="../../FrontOffice/login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../../FrontOffice/mainpage/index.html">Return to Front Office</a></li>
            <li><a href="index.php">BackOffice: Manage Orders</a></li>
        </ul>
    </nav>
    <!-- Header, navigation, and other sections remain the same -->
    <main>
        <h1>Edit Order #<?php echo htmlspecialchars($order_id); ?></h1>

        <!-- Display Success or Error Messages -->
        <?php if (!empty($success)): ?>
            <p class="success"><?php echo htmlspecialchars($success); ?></p>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <!-- Edit Order Form -->
        <form action="edit_order.php?id=<?php echo $order_id; ?>" method="post">
            <label for="customer_name">Customer Name:</label>
            <input type="text" id="customer_name" name="customer_name" value="<?php echo htmlspecialchars($customer_name); ?>" required>

            <label for="customer_address">Customer Address:</label>
            <textarea id="customer_address" name="customer_address" required><?php echo htmlspecialchars($customer_address); ?></textarea>

            <label for="payment_method">Payment Method:</label>
            <input type="text" id="payment_method" name="payment_method" value="<?php echo htmlspecialchars($payment_method); ?>" required>

            <button type="submit">Update Order</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <script src="scripts.js"></script></body>
</html>