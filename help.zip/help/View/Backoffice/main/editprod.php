<?php
// BackOffice/DB/editprod.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - GreenRoot</title>
    <link rel="stylesheet" href="styles.css"> <!-- Adjust the path if necessary -->
</head>
<body>
    <header>
        <div class="header-container">
            <img src="images/logo.png" alt="Logo" />
            <div class="header-buttons">
                <a href="../FrontOffice/mainpage/basket.php" class="basket-button">Basket</a>
                <a href="../../FrontOffice/login/login.html" class="signin-button">Login</a>
            </div>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../../FrontOffice/mainpage/index.html">Home</a></li>
            <li><a href="../../FrontOffice/mainpage/products.php">Our Products</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Events</a></li>
        </ul>
    </nav>

    <main>
        <h1>Edit Product</h1>
        <?php
        // Include the database connection file
        require_once '../../../config.php';

        // Initialize variables
        $name = $description = $price = $availability = $image = "";
        $error = $success = "";

        // Check if 'id' is set in GET request
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $product_id = intval($_GET['id']);

            // Fetch the product details from the database
            $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();

            if ($product) {
                // Populate variables with existing data
                $name = htmlspecialchars($product['name']);
                $description = htmlspecialchars($product['description']);
                $price = htmlspecialchars($product['price']);
                $availability = htmlspecialchars($product['availability']);
                $image = htmlspecialchars($product['image']);
            } else {
                echo "<p class='error'>Product not found.</p>";
                exit();
            }
        } else {
            echo "<p class='error'>Invalid product ID.</p>";
            exit();
        }

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Retrieve and sanitize form data
            $name = htmlspecialchars(trim($_POST['name']));
            $description = htmlspecialchars(trim($_POST['description']));
            $price = floatval($_POST['price']);
            $availability = $_POST['availability'];

            // Handle image upload if a new image is provided
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['image']['name'];
                $filetype = $_FILES['image']['type'];
                $filesize = $_FILES['image']['size'];

                // Verify file extension
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                if (!in_array(strtolower($ext), $allowed)) {
                    $error = "Please select a valid file format.";
                }

                // Verify file size - 5MB maximum
                if ($filesize > 5 * 1024 * 1024) {
                    $error = "File size is larger than the allowed limit.";
                }

                // Verify MIME type
                if (in_array($filetype, ['image/jpeg', 'image/png', 'image/gif'])) {
                    // Define the target directory
                    $targetDir = "../../FrontOffice/mainpage/images/";

                    // Ensure the target directory exists
                    if (!is_dir($targetDir)) {
                        mkdir($targetDir, 0755, true);
                    }

                    // Generate a unique filename to prevent overwriting
                    $uniqueFilename = uniqid() . "_" . basename($filename);
                    $targetFilePath = $targetDir . $uniqueFilename;

                    // Check if file already exists
                    if (file_exists($targetFilePath)) {
                        $error = "A file with this name already exists.";
                    } else {
                        // Move the uploaded file to the target directory
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath)) {
                            // Optionally, delete the old image file
                            if (file_exists($image)) {
                                unlink($image);
                            }
                            // Update the image path
                            $image = $targetFilePath;
                        } else {
                            $error = "Failed to upload the new image.";
                        }
                    }
                } else {
                    $error = "Invalid file type.";
                }
            }

            // If no errors, update the product in the database
            if (empty($error)) {
                $updateStmt = $pdo->prepare('UPDATE products SET name = ?, description = ?, price = ?, availability = ?, image = ? WHERE id = ?');
                if ($updateStmt->execute([$name, $description, $price, $availability, $image, $product_id])) {
                    $success = "Product updated successfully!";
                } else {
                    $error = "Failed to update the product.";
                }
            }
        }
        ?>

        <!-- Display Success or Error Messages -->
        <?php if (!empty($success)): ?>
            <p class="success"><?php echo $success; ?></p>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- Edit Product Form -->
        <form action="editprod.php?id=<?php echo $product_id; ?>" method="post" enctype="multipart/form-data" class="add-product-form">
            <label for="name" class="label-text">Product Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $name; ?>" placeholder="e.g., Organic Bananas" required>

            <label for="description" class="label-text">Description:</label>
            <textarea id="description" name="description" rows="4" placeholder="Describe the product..." required><?php echo $description; ?></textarea>

            <label for="price" class="label-text">Price (per KG):</label>
            <input type="number" step="0.01" id="price" name="price" value="<?php echo $price; ?>" placeholder="e.g., 5.99" required>

            <label for="availability" class="label-text">Availability:</label>
            <select id="availability" name="availability" required>
                <option value="In Stock" <?php if ($availability == 'In Stock') echo 'selected'; ?>>In Stock</option>
                <option value="Limited Stock" <?php if ($availability == 'Limited Stock') echo 'selected'; ?>>Limited Stock</option>
                <option value="Out of Stock" <?php if ($availability == 'Out of Stock') echo 'selected'; ?>>Out of Stock</option>
            </select>

            <label for="image" class="label-text">Product Image:</label>
            <input type="file" id="image" name="image" accept="image/*" class="file-input">
            <p>Current Image:</p>
            <img src="<?php echo $image; ?>" alt="<?php echo $name; ?>" class="current-image">

            <button type="submit" class="upload-button">Update Product</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2024 GreenRoot. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | 
            <a href="#">Terms of Service</a>
        </div>
    </footer>

    <script src="scripts.js"></script>
</body>
</html>